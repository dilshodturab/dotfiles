#!/bin/bash

# Waybar Timer & Stopwatch Menu
STATE_FILE="/tmp/waybar_timer_state"

save_state() {
    echo "$1|$2|$3|$4" > "$STATE_FILE"
    # Signal Waybar to refresh
    pkill -RTMIN+11 waybar
}

echo "--- TAYMER VA SEKUNDOMER ---"
echo "1) Sekundomer (Stopwatch)"
echo "2) Taymer (Timer)"
echo "3) To'xtatish (Stop)"
echo "4) Chiqish (Exit)"
read -p "Tanlang: " choice

case $choice in
    1)
        save_state "STOPWATCH" "$(date +%s)" "0" "0"
        echo "Sekundomer boshlandi."
        ;;
    2)
        read -p "Vaqtni kiriting (minutlarda): " mins
        if [[ $mins =~ ^[0-9]+$ ]]; then
            duration=$((mins * 60))
            save_state "TIMER" "$(date +%s)" "$duration" "0"
            echo "Taymer boshlandi: $mins minut."
        else
            echo "Xato: Faqat raqam kiriting."
            sleep 1
        fi
        ;;
    3)
        save_state "IDLE" "0" "0" "0"
        echo "To'xtatildi."
        ;;
    4)
        exit 0
        ;;
    *)
        echo "Noto'g'ri tanlov."
        sleep 1
        ;;
esac
sleep 0.5
