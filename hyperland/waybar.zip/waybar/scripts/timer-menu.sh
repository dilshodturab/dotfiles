#!/bin/bash

# Waybar Timer & Stopwatch Menu
STATE_FILE="/tmp/waybar_timer_state"

save_state() {
    echo "$1|$2|$3|$4" > "$STATE_FILE"
    # Signal Waybar to refresh
    pkill -RTMIN+11 waybar
}

while true; do
    clear
    echo "--- TAYMER VA SEKUNDOMER ---"
    echo " (s) Sekundomer (Stopwatch)"
    echo " (t) Taymer (Timer)"
    echo " (d) To'xtatish (Stop/Delete)"
    echo " (q) Chiqish (Quit)"
    echo -n "Tanlang: "
    read -n 1 choice
    echo "" # New line after read -n 1

    case $choice in
        s|S)
            save_state "STOPWATCH" "$(date +%s)" "0" "0"
            echo "Sekundomer boshlandi."
            sleep 1
            ;;
        t|T)
            while true; do
                read -p "Vaqtni kiriting (minutlarda): " mins
                if [[ $mins =~ ^[0-9]+$ ]] && [ "$mins" -gt 0 ]; then
                    duration=$((mins * 60))
                    save_state "TIMER" "$(date +%s)" "$duration" "0"
                    echo "Taymer boshlandi: $mins minut."
                    sleep 1
                    break
                else
                    echo "Xato: Faqat musbat raqam kiriting (masalan: 5, 10, 60)."
                fi
            done
            ;;
        d|D)
            save_state "IDLE" "0" "0" "0"
            echo "To'xtatildi."
            sleep 1
            ;;
        q|Q)
            echo "Chiqilmoqda..."
            exit 0
            ;;
        *)
            echo "Noto'g'ri tanlov: $choice"
            sleep 1
            ;;
    esac
done
