#!/bin/bash

# Waybar Timer & Stopwatch Script
# State file format: MODE|START_EPOCH|DURATION_SECONDS|END_ACTION_TIME
STATE_FILE="/tmp/waybar_timer_state"

get_state() {
    if [ -f "$STATE_FILE" ]; then
        cat "$STATE_FILE"
    else
        echo "IDLE|0|0|0"
    fi
}

save_state() {
    echo "$1|$2|$3|$4" > "$STATE_FILE"
}

format_time() {
    local seconds=$1
    local h=$((seconds / 3600))
    local m=$(((seconds % 3600) / 60))
    local s=$((seconds % 60))
    if [ $h -gt 0 ]; then
        printf "%d:%02d:%02d" $h $m $s
    else
        printf "%02d:%02d" $m $s
    fi
}

status() {
    local state=$(get_state)
    local mode=$(echo "$state" | cut -d'|' -f1)
    local start=$(echo "$state" | cut -d'|' -f2)
    local duration=$(echo "$state" | cut -d'|' -f3)
    local end_action=$(echo "$state" | cut -d'|' -f4)
    local now=$(date +%s)

    # Check if alarm should be active
    if [ "$mode" == "ALARM" ]; then
        local elapsed=$((now - end_action))
        if [ $elapsed -lt 10 ]; then
            echo "{\"text\": \"󱎫 ALARM\", \"class\": \"alarm\", \"tooltip\": \"Vaqt tugadi!\"}"
            exit 0
        else
            mode="IDLE"
            save_state "IDLE" "0" "0" "0"
        fi
    fi

    case $mode in
        STOPWATCH)
            local elapsed=$((now - start))
            echo "{\"text\": \"󱎫 $(format_time $elapsed)\", \"class\": \"active\", \"tooltip\": \"Sekundomer ishlayapti\nBosilsa to'xtaydi\"}"
            ;;
        TIMER)
            local remaining=$((start + duration - now))
            if [ $remaining -le 0 ]; then
                save_state "ALARM" "0" "0" "$now"
                echo "{\"text\": \"󱎫 ALARM\", \"class\": \"alarm\", \"tooltip\": \"Vaqt tugadi!\"}"
            else
                echo "{\"text\": \"󱎫 $(format_time $remaining)\", \"class\": \"active\", \"tooltip\": \"Taymer: $(format_time $remaining) qoldi\nBosilsa to'xtaydi\"}"
            fi
            ;;
        *)
            echo "{\"text\": \"󱎫\", \"class\": \"idle\", \"tooltip\": \"Taymer yoki Sekundomerni yoqish uchun bosing\"}"
            ;;
    esac
}

case $1 in
    status)
        status
        ;;
    stop)
        save_state "IDLE" "0" "0" "0"
        pkill -RTMIN+11 waybar
        ;;
    *)
        # Default to showing status
        status
        ;;
esac
